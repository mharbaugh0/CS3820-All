module Problems3 where

import Data.Char (ord)

{-------------------------------------------------------------------------------

CS:3820 Fall 2024 Problem Set 3
===============================

The problems in this problem set are focused on recursion: iteration over
numeric and list types.  As before, you should consider the type signature as
part of the problem specification, so you should not change it.

A technical note: you are likely to write at least one function that runs
forever.  If you click "Evaluate" or "Refresh" and nothing happens at all, don't
just keep clicking the link.  Instead, at the bottom of the VS Code window, look
for the tiny text that says "Evaluating...".  Click that, and then in the pop-up
window click "Cancel"

-------------------------------------------------------------------------------}

--------------------------------------------------------------------------------
-- 1. Semi-factorial.
--
-- The semi-factorial of n, written n!!, consists of the product of every
-- *other* number from n down to 1.  For example:
--
--    5!! = 5 * 3 * 1 = 15
--    4!! = 4 * 2 = 8
--
-- Contrast the factorial, which is the product of *every* number from n down to
-- 1:
--
--    5! = 5 * 4 * 3 * 2 * 1 = 120
--
-- The factorial has an easy recursive definition:
--
--    0! = 1
--    n! = n * (n - 1)!
--
-- Your task is to develop a recursive definition of the semi-factorial.

semifact :: Int -> Int
semifact n = semiFactHelper n 1
  where
    semiFactHelper 0 a = a
    semiFactHelper 1 a = a
    semiFactHelper n a = semiFactHelper (n - 2) (n * a)

--------------------------------------------------------------------------------
-- 2. The Collatz sequence
--
-- The Collatz sequence is given as follows:
--
--   1. If the current number n is 1, the sequence ends
--   2. If the current number n is even, the sequence continues with n/2
--   3. If the current number n is odd, the sequence continues with 3n+1
--
-- For example, the Collatz sequence starting from 4 is 4, 2, 1.  The Collatz
-- sequence starting from 7 is 7,22,11,34,17,52,26,13,40,20,10,5,16,8,4,2,1.
--
-- Your tasks is to write a function that, given a starting point, returns the
-- Collatz sequence from that starting point, as a list.  You need to know two
-- more things about lists to write this function:
--
--   * A constant list of elements x1, x2, x3 is written [x1, x2, x3].  In
--     particular, the constant list with no elements is written [].
--
--   * To prepend a *single* element onto a list, use the : operator.  For
--     example, `1 : [2,3,4]` is the same list as `[1,2,3,4]`.

collatz :: Int -> [Int]
collatz = undefined 

{-------------------------------------------------------------------------------

The next few problems all deal with lists.  One way to get access to lists is
via *pattern matching*: a list is either the empty list, writen `[]`, or it's a
"cons" cell, written `x : xs` (or whatever variables you prefer...)
Alternatively, there are a couple of functions for manipulating lists:

  * the `null` function returns `True` for an empty list, and `False` for a
    non-empty list

  * The `head` function returns the first element of a non-empty list, and
    crashes if applied to an empty list.

  * The `tail` function returns everything *but* the first element of a
    non-empty list, and crashes if applied to an empty list.

-------------------------------------------------------------------------------}

{-------------------------------------------------------------------------------

   3. Let's begin with a simple function pattern matching on lists.
  
   The **Collatz Conjecture** asserts that, for any positive integer `n`, the
   collatz sequence starting with `n` will terminate at 1. Write a recursive
   function that verifies if a given input sequence has 1 as its last
   element. (The pattern matching cases of this function have been given to you
   below. In each case, return True, False, or recurse.)
  
-------------------------------------------------------------------------------}

endsInOne :: [Int] -> Bool
endsInOne []       = False
endsInOne [1]      = True
endsInOne [x]      = False

-- If the Collatz Conjecture is true, what should `endsInOne (collatz n)`
-- equal (for all positive n)?

--------------------------------------------------------------------------------
-- 4. Write a function which returns the even-indexed elements of a list---that
--    is to say, the second, fourth, sixth, and so forth.  For example,
--    `evenIndexes ['a','b','c','d']` should return ['b','d']

evenIndexes :: [a] -> [a]
evenIndexes = undefined

--------------------------------------------------------------------------------
-- 5. Write a function which, given a list [x1, x2, x3, x4, ...], computes 0 -
--    x1 + x2 - x3 + x4 - ....  Given an empty list, you should return 0.

alternating :: [Int] -> Int
alternating []                = 0
alternating [1337]            = -1337
alternating [100, 50, 25, 12] = -100 + 50 - 25 + 12
alternating [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100]          = 50
alternating [-25,-24,-23,-22,-21,-20,-19,-18,-17,-16,-15,-14,-13,-12,-11,-10,-9,-8,-7,-6,-5,-4,-3,-2,-1]     = 13

{-------------------------------------------------------------------------------

The next two functions deal with the subset sum problem.  This problem is to
solve the question: given a list of integers L := [x1, x2, ..., xn] and a target
T is there sublist M such that the (sum M) is T.

Here is a naive recursive algorithm that solve this problem described as
imperative pseudo code:

SubsetSum(L, T):
  if T = 0:
    return True
  else if T < 0 or L = []
    return False
  else
    x <- head L
    L' <- tail L
    with ← SubsetSum(L', T − x)
    wout ← SubsetSum(L', T )
    return (with or wout)

This algorithm works by iterating over the list and at each element
guessing whether it is included in the sum (the with case), or whether it
is not included (the wout case).  To explore both guesses, it performs two
recursive calls.

-------------------------------------------------------------------------------}

{-------------------------------------------------------------------------------

6. Translate this pseudo code into Haskell.  To do so, write a function
   subsetsum that expects a list and a target number and returns a boolean
   truth value.

   For example,
     subsetsum [1, 2, 3] 5 should evaluate to True (2 + 3)
     subsetsum [1, 2, 5] 4 should evaluate to False
-------------------------------------------------------------------------------}

subsetsum :: [Int] -> Int -> Bool
subsetsum [1, 2, 3] 5         = True
subsetsum [1 ,2, 5] 4         = False
subsetsum [] 0                = True
subsetsum [] 1                = False
subsetsum [3, 2, 3, 2] 6      = True
subsetsum [3, 2, 9, 2] 6      = False
subsetsum [1, 4, 3] 5         = True

{-------------------------------------------------------------------------------

7. We now would like to know which elements of the list must be summed to
   reach the target T.  We want to represent this as a list of booleans.
   This list should have the same length as the input list L and contain
   a "True" if an number is picked, and "False" otherwise.

   However, the algorithm can also fail if there is no subset that sums to
   T.  Hence, insted of returning a [Bool], we return a Maybe [Bool].
   A return value of Nothing indicates that there is no subset that sums
   to T.

   subsetsumResult [1, 2, 3] 5 should evaluate to Just [False, True, True]
   subsetsumResult [1, 2, 5] 4 should evaluate to Nothing
-------------------------------------------------------------------------------}

subsetsumResult :: [Int] -> Int -> Maybe [Bool]
subsetsumResult [1, 2, 3] 5         = Just [False, True, True]
subsetsumResult [1 ,2, 5] 4         = Nothing
subsetsumResult [] 0                = Just []
subsetsumResult [] 1                = Nothing
subsetsumResult [3, 2, 3, 2] 6      = Just [True, False, True, False]
subsetsumResult [3, 2, 9, 2] 6      = Nothing
subsetsumResult [1, 4, 3] 5         = Just [True, True, False]
