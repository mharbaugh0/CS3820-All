module Problems6 where

{-------------------------------------------------------------------------------

CS:3820 Fall 2024 Problem Set 6
===============================

This problem set includes exercises related to type classes in Haskell.

-------------------------------------------------------------------------------}

-- [Exercise 1] Implementing Eq for a Custom Binary Tree
{-

See the binary tree datatype defined below.

Make it an instance of the `Eq` type class so that two trees are considered
equal if they have the same structure and the stored elements are equal.

-}

data BinaryTree a = Empty | Node a (BinaryTree a) (BinaryTree a)
                  deriving (Show)

-- Implement the Eq instance for BinaryTree
instance Eq a => Eq (BinaryTree a) where
  -- (==) :: Eq a => BinaryTree a -> BinaryTree a -> Bool
  (==) Empty Empty = True
  (==) (Node a Empty Empty) (Node b Empty Empty) = False
  (==) (Node a x Empty) (Node b y Empty) = False
  (==) (Node a Empty x) (Node b Empty y) = False
  (==) _ _ = True

{-------------------------------------------------------------------------------

[Exercise 2] Implementing Monoid for a Custom Data Type
-------------------------------------------------------

Consider the following data type that represents a simple mathematical expression:

-}

data Expr = Const Int
          | Add [Expr]
          deriving (Show, Eq)

{-

Implement the `Monoid` type class for `Expr` such that `mempty` represents
a zero constant, and the binary operation `mappend` (or `<>`) combines
two expressions.  You will have to make a distinction between constants
and additions.

Recall the monoid laws:

x <> mempty = x
mempty <> x = x
(x <> y) <> z = x <> (y <> z)
-}

-- Implement the Semigroup instance for Expr
instance Semigroup Expr where
    -- (<>) :: Expr -> Expr -> Expr
    (<>) (Const x) (Const y) = Const (x + y) 
    (<>) (Const x) (Add xs) = Add (Const x : xs)  
    (<>) (Add xs) (Const y) = Add (xs ++ [Const y])
    (<>) (Add xs) (Add ys) = Add (xs ++ ys) 

    
-- Implement the Monoid instance for Expr
instance Monoid Expr where
    -- mempty :: Expr
     mempty = Const 0

{-------------------------------------------------------------------------------

[Exercise 3] Implementing Functor for a Custom Data Type
--------------------------------------------------------

The Box datatype defined below is a very simple data type: it stores a single
value.

Implement the `Functor` type class for `Box`.

-}

data Box a = Box a
  deriving (Show, Eq)

-- Implement the Functor instance for Box
instance Functor Box where
    -- fmap :: (a -> b) -> Box a -> Box b
    fmap a (Box b) = Box (a b)

{-------------------------------------------------------------------------------

[Exercise 4] Using an Existing Instance to Implement Another
------------------------------------------------------------

Recall that List datatypes are instances of both the `Functor` and `Monoid`,
typeclass.

Define a function `combineAndMap` that takes a list of lists, concatenates
them into a single list (using the monoid operation), and then applies
a function to each element (using the functor operation).

-}

combineAndMap :: (a -> b) -> [[a]] -> [b]
combineAndMap f xss = map f (mconcat xss)

{-------------------------------------------------------------------------------

[Exercise 5] Implementing Ord Based on an Existing Eq Instance
--------------------------------------------------------------

Implement the `Ord` type class for the `BinaryTree` data type from Exercise 1.

A tree `A` is considered to be less than another tree `B`, if the element in
the root of `A` is less than the element in the root of `B`.  If the
root elements are the same, then `A` is less than `B` if the left subtree
of `A` is less than the left subtree of `B`.  If the left subtrees are the
same, then the right subtrees are compared in the same manner.

A leaf (`Empty`) is always larger than a `Node`.

-}

-- data Ordering = LT | EQ | GT 

-- Implement the Ord instance for BinaryTree
instance (Ord a) => Ord (BinaryTree a) where
    -- compare :: Ord a => BinaryTree a -> BinaryTree a -> Ordering
    compare Empty (Node _ _ _) = GT  
    compare (Node _ _ _) Empty = LT  
    compare (Node a l1 r1) (Node b l2 r2) =
        case compare a b of
            EQ -> case compare l1 l2 of
                EQ -> compare r1 r2
                other -> other
            other -> other
    compare _ _ = EQ
